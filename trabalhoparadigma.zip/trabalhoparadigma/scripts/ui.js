import { formatarBoolean } from './utils.js';
import { isEmbarcacaoMiuda } from './filters.js';

const elementos = {
    tableBody: document.getElementById('tableBody'),
    tableTitle: document.getElementById('tableTitle'),
    totalCount: document.getElementById('totalCount'),
    miudasCount: document.getElementById('miudasCount'),
    percentualMiudas: document.getElementById('percentualMiudas'),
    relatorioDetails: document.getElementById('relatorioDetails'),
    btnGerarDados: document.getElementById('btnGerarDados'),
    btnFiltrarMiudas: document.getElementById('btnFiltrarMiudas'),
    btnMostrarTodos: document.getElementById('btnMostrarTodos')
};


const gerarLinhaTabela = (embarcacao) => {
    const status = isEmbarcacaoMiuda(embarcacao) ? 'miuda' : 'nao-miuda';
    const statusText = isEmbarcacaoMiuda(embarcacao) ? 'MIÚDA' : 'NÃO MIÚDA';
    
    return `
        <tr>
            <td>${embarcacao.id}</td>
            <td>${embarcacao.comprimento}m</td>
            <td>${embarcacao.motorizacao}HP</td>
            <td>${formatarBoolean(embarcacao.possuiConvesAberto)}</td>
            <td>${formatarBoolean(embarcacao.possuiCabineHabitavel)}</td>
            <td><span class="status-${status}">${statusText}</span></td>
        </tr>
    `;
};


export const atualizarTabela = (embarcacoes, titulo = 'Todas as Embarcações') => {
    elementos.tableTitle.textContent = titulo;
    elementos.tableBody.innerHTML = embarcacoes.map(gerarLinhaTabela).join('');
};


export const atualizarEstatisticas = (relatorio) => {
    elementos.totalCount.textContent = relatorio.total;
    elementos.miudasCount.textContent = relatorio.miudas;
    elementos.percentualMiudas.textContent = `${relatorio.percentualMiudas}%`;
};


export const atualizarRelatorio = (relatorio) => {
    elementos.relatorioDetails.innerHTML = `
        <p><strong>Total de embarcações:</strong> ${relatorio.total}</p>
        <p><strong>Embarcações miúdas:</strong> ${relatorio.miudas} (${relatorio.percentualMiudas}%)</p>
        <p><strong>Embarcações não miúdas:</strong> ${relatorio.naoMiudas}</p>
        <p><strong>Com motor:</strong> ${relatorio.comMotor} (${relatorio.percentualComMotor}%)</p>
        <p><strong>Com cabine habitável:</strong> ${relatorio.comCabine} (${relatorio.percentualComCabine}%)</p>
        <p><strong>Com convés aberto:</strong> ${relatorio.comConvesAberto} (${relatorio.percentualConvesAberto}%)</p>
    `;
};


export const getElementos = () => elementos;