import { estado, inicializarDados } from './data.js';
import { filtrarEmbarcacoesMiudas, gerarRelatorio } from './filters.js';
import { atualizarTabela, atualizarEstatisticas, atualizarRelatorio, getElementos } from './ui.js';

const atualizarInterface = (embarcacoes, titulo = 'Todas as Embarcações') => {
    atualizarTabela(embarcacoes, titulo);
    const relatorio = gerarRelatorio(estado.embarcacoes);
    atualizarEstatisticas(relatorio);
    atualizarRelatorio(relatorio);
};


const inicializarAplicacao = () => {
    
    const dadosIniciais = inicializarDados();
    
    
    atualizarInterface(dadosIniciais);
};


const configurarEventos = () => {
    const elementos = getElementos();
    
    elementos.btnGerarDados.addEventListener('click', () => {
        const novosDados = inicializarDados();
        atualizarInterface(novosDados);
        estado.filtroAtivo = false;
    });
    
    elementos.btnFiltrarMiudas.addEventListener('click', () => {
        const miudas = filtrarEmbarcacoesMiudas(estado.embarcacoes);
        atualizarTabela(miudas, 'Embarcações Miúdas (Legalizáveis)');
        estado.filtroAtivo = true;
    });
    
    elementos.btnMostrarTodos.addEventListener('click', () => {
        atualizarInterface(estado.embarcacoes);
        estado.filtroAtivo = false;
    });
};

document.addEventListener('DOMContentLoaded', () => {
    inicializarAplicacao();
    configurarEventos();
});