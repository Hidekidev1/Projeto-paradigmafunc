import { gerarNumeroAleatorio, arredondar, toBoolean } from './utils.js';

// Gerador de dados das embarcações
const criarEmbarcacao = (id) => ({
    id: id,
    comprimento: arredondar(gerarNumeroAleatorio(2, 12), 1),
    motorizacao: Math.random() > 0.3 ? Math.floor(gerarNumeroAleatorio(10, 150)) : 0,
    possuiConvesAberto: toBoolean(),
    possuiCabineHabitavel: Math.random() > 0.7
});


export const gerarEmbarcacoes = (quantidade = 50) => 
    Array.from({ length: quantidade }, (_, i) => criarEmbarcacao(i + 1));


export let estado = {
    embarcacoes: [],
    embarcacoesFiltradas: [],
    filtroAtivo: false
};


export const inicializarDados = () => {
    estado.embarcacoes = gerarEmbarcacoes(50);
    estado.embarcacoesFiltradas = [];
    estado.filtroAtivo = false;
    return estado.embarcacoes;
};