// Funções utilitárias puras
export const gerarNumeroAleatorio = (min, max) => Math.random() * (max - min) + min;

export const arredondar = (valor, casas = 2) => Number(valor.toFixed(casas));

export const toBoolean = () => Math.random() > 0.5;

export const formatarBoolean = (valor) => valor ? "Sim" : "Não";

export const calcularPercentual = (parte, total) => arredondar((parte / total) * 100, 1);

export const contarPorPredicado = (array, predicado) => array.filter(predicado).length;