// Predicados para os critérios de embarcações miúdas
export const criterioA = (embarcacao) => 
    embarcacao.comprimento <= 5;

export const criterioB = (embarcacao) => 
    embarcacao.comprimento <= 8 && 
    embarcacao.possuiConvesAberto && 
    embarcacao.motorizacao <= 50 && 
    !embarcacao.possuiCabineHabitavel;

export const criterioC = (embarcacao) => 
    embarcacao.comprimento <= 8 && 
    !embarcacao.possuiConvesAberto && 
    !embarcacao.possuiCabineHabitavel && 
    embarcacao.motorizacao <= 50;


export const isEmbarcacaoMiuda = (embarcacao) => 
    criterioA(embarcacao) || criterioB(embarcacao) || criterioC(embarcacao);


export const filtrarEmbarcacoesMiudas = (embarcacoes) => 
    embarcacoes.filter(isEmbarcacaoMiuda);


export const gerarRelatorio = (embarcacoes) => {
    const total = embarcacoes.length;
    const miudas = filtrarEmbarcacoesMiudas(embarcacoes).length;
    const naoMiudas = total - miudas;
    
    const comMotor = embarcacoes.filter(e => e.motorizacao > 0).length;
    const comCabine = embarcacoes.filter(e => e.possuiCabineHabitavel).length;
    const comConvesAberto = embarcacoes.filter(e => e.possuiConvesAberto).length;
    
    return {
        total,
        miudas,
        naoMiudas,
        percentualMiudas: (miudas / total * 100).toFixed(1),
        comMotor,
        percentualComMotor: (comMotor / total * 100).toFixed(1),
        comCabine,
        percentualComCabine: (comCabine / total * 100).toFixed(1),
        comConvesAberto,
        percentualConvesAberto: (comConvesAberto / total * 100).toFixed(1)
    };
};